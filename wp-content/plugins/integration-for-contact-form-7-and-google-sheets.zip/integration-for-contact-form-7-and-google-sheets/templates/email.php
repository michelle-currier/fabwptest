<?php
  if ( ! defined( 'ABSPATH' ) ) {
     exit;
 } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;" charset="UTF-8" />
</head>
<body style="margin: 0px; background-color: #FFFFFF; font-family: Helvetica, Arial, sans-serif; font-size:12px;" text="#444444" bgcolor="#FFFFFF" link="#21759B" alink="#21759B" vlink="#21759B" marginheight="0" topmargin="0" marginwidth="0" leftmargin="0"><table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="backgroundTable" style="margin: 0;padding: 0;background-color: #EBEBEB;height: 100% !important;width: 100% !important;">
            	<tbody><tr>
                	<td align="center" valign="top">
                        <!-- // End Template Preheader \\ -->
                    	<table border="0" cellpadding="0" cellspacing="0" width="600" style="border-top: 5px solid #C35050;" id="templateContainer">
                        	<tbody><tr>
                            	<td align="center" valign="top" id="templateHeader" style="background-color: #FFFFFF;border-top: 0;border-bottom: 0px solid #D9D9D9;">
                                    <!-- // Begin Template Header \\ -->
                                	<table border="0" cellpadding="0" cellspacing="0" width="100%">
                                        <tbody><tr>
                                            <td class="headerContent" style="color: #C35050;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 100%;padding: 20px;text-align: left;vertical-align: middle; border-top:1px solid #B24747;">
                                            	<span style="color:#C35050;"><span style="font-size:24px">{title}</span></span>
												
                                            </td>
                                        </tr>
										<tr><td>	<p style="padding-left: 10px; padding-bottom: 20px;color: #303030;font-family: Helvetica;font-size: 15px;line-height: 150%;text-align: left;">{msg}</p>
                                    </tbody></table>
                                    <!-- // End Template Header \\ -->
                                </td>
                            </tr>
                        	<tr>
                            	<td align="center" valign="top">
                                    <!-- // Begin Template Body \\ -->
                                	<table border="0" cellpadding="0" cellspacing="0" width="600" id="templateBody" style="background-color: #FFFFFF;border-top: 0;border-bottom: 1px solid #CACACA;">
                                    	<tbody>
								{sf_contents}
					<tr><td valign="top" style="padding: 40px"></td></tr>
                                    </tbody></table>
                                    <!-- // End Template Body \\ -->
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>

            </tbody></table>
		</body>	