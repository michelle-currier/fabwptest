<?php return array('dependencies' => array(), 'version' => 'a145d0113e969f692877');
