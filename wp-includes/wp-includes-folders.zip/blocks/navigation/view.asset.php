<?php return array('dependencies' => array(), 'version' => 'c7aadf427ad3311e0624');
