<?php return array('dependencies' => array(), 'version' => 'ee101e08820687c9c07f');
